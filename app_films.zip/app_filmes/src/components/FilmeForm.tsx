import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createFilme, getFilmeById, updateFilme } from '../services/api';

interface Filme {
    name: string;
    category: string;
    price: number;
    quantity: number;
}
export function FilmeForm() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [Filme, setFilme] = useState<Filme>({
        name: '',
        category: '',
        price: 0,
        quantity: 0,
    });

    useEffect(() => {
        if (id) {
            loadFilme();
        }
    }, [id]);

    const loadFilme = async () => {
        try {
            const response = await getFilmeById(id as string);
            setFilme(response.data);

        } catch (error) {
            console.error("Error loading Filme data", error);
        }
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFilme({
            ...Filme,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (id) {
                await updateFilme(id, Filme);
            } else {
                await createFilme(Filme);
            }
            navigate('/');
        } catch (error) {
            console.error("Error saving Filme", error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <div>
                <label>Name</label>
                <input
                    type="text"
                    name="name"
                    value={Filme.name}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Category</label>
                <input
                    type="text"
                    name="category"
                    value={Filme.category}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Price</label>
                <input
                    type="number"
                    name="price"
                    value={Filme.price}
                    onChange={handleChange}
                />
            </div>
            <div>
                <label>Quantity</label>
                <input
                    type="number"
                    name="quantity"
                    value={Filme.quantity}
                    onChange={handleChange}
                />
            </div>
            <button type="submit">Save</button>
        </form>
    );
}