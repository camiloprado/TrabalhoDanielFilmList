import { useEffect, useState } from 'react';
import { getFilmes, deleteFilme } from '../services/api';
import { Link } from 'react-router-dom';

interface Filme {
    id: string;
    name: string;
    description: string;
    price: number;
    quantity: number;
}

export function FilmeList() {
    const [filme, setFilme] = useState<Filme[]>([]);
    useEffect(() => {
        loadFilme();
    }, []);

    const loadFilme = async () => {
        const response = await getFilmes();
        setFilme(response.data);
    };

    const handleDelete = async (id: string) => {
        await deleteFilme(id);
        loadFilme();
    };

    return (
        <div>
            <h1>Lista de Filmes</h1>
            <Link to="/add">Add Filme</Link>
            <ul>
                {filme.map((filme) => (
                    <li key={filme.id}>
                        {filme.name} - ${filme.price} - {filme.quantity} units
                        <Link to={`/edit/${filme.id}`}>Edit</Link>
                        <button onClick={() => handleDelete(filme.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
}
