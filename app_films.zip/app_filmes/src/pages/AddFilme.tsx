import {FilmeForm} from '../components/FilmeForm';

export function AddFilme() {
    return (
        <div>
            <h1>Add Filme</h1>
            <FilmeForm />
        </div>
    );
}
