import { FilmeList } from "../components/FilmeList";


export function Home() {
    return (
        <div>
            <h1>Daniel's Locadora</h1>
            <FilmeList />
        </div>
    );
}