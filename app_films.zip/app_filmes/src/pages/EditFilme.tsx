import { FilmeForm } from '../components/FilmeForm';

export function EditFilme() {
    return (
        <div>
            <h1>Edit Filme</h1>
            <FilmeForm />
        </div>
    );
}