import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import {Home} from './pages/Home';
import {AddFilme} from './pages/AddFilme';
import { EditFilme } from './pages/EditFIlme';


export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/add" element={<AddFilme />} />
        <Route path="/edit/:id" element={<EditFilme />} />
      </Routes>
    </Router>
  );
}